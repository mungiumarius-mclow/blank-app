package com.psadiag

import android.app.Application

class PSADiagApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
